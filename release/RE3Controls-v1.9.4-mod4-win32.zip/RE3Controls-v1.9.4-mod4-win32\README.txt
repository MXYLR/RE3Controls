﻿RE3Controls v1.9.4-mod4 for Resident Evil 5
===========================================

RE3 (2020) style controls for RE5: free over-the-shoulder camera, camera-relative
movement, walking while aiming, reload and weapon switch on the move, a centred
crosshair, quick turn, keyboard and mouse support.

Base: RE3Controls v1.9 by bananzaza (MIT) + notencio/RE3Controls v1.9.4, plus the
fixes and features listed in CHANGES.txt.

INSTALL
-------
Copy xinput1_3.dll into the game folder, next to re5dx9.exe, and start the game.
On the first run the mod writes RE3Controls.ini (all settings, commented) and
RE3Controls.log next to the DLL.  Uninstall: delete the DLL (and the ini).

NEW IN THIS BUILD
-----------------
- Shoulder: the key works ANY time, aiming or not (Camera/ShoulderSwapAlways=1); the knife stays on LB. Default: the character stands on the LEFT of the screen (Chris on the left, Sheva on the right; Camera/
  ShoulderAuto, ShoulderLeftKinds).  RB while aiming still swaps manually.
- Plain-gun zoom: F zooms in, C zooms out while aiming a gun (Aim/ZoomKeys,
  ZoomFovStep, ZoomMaxStep).  The sniper scope keeps its own zoom.
- Sniper scope: walking while scoped (ScopeWalk=1) and the game's own scope aim
  is no longer disturbed by the mod.
- The quick knife slash can be turned with the mouse / right stick.

FIRST-RUN NOTE
--------------
re5dx9.exe is wrapped in Enigma Protector, which checks its own image for a few
seconds after start-up; the mod waits (HookDelayMs=3000) before hooking.  If the
game quits with "Program integrity check failed", relaunch it or raise
HookDelayMs under [Advanced].

LICENCE
-------
RE3Controls MIT (c) bananzaza and contributors; MinHook BSD 2-clause (c) TsudaKageyu.
Unofficial build: keep both licence files when redistributing.


RE3Controls v1.9.4-mod4（中文说明）
==================================

RE3 重制版风格操作：自由肩部视角、相机相对移动、瞄准中行走、移动中换弹换枪、准星居中、
快速转身、完整键鼠支持。

基线：bananzaza 的 RE3Controls v1.9（MIT）+ notencio/RE3Controls v1.9.4，
再加上 CHANGES.txt 里的修复与新功能。

安装
----
把 xinput1_3.dll 复制到游戏根目录（与 re5dx9.exe 同层），直接启动游戏。
首次运行会在 DLL 旁生成带注释的 RE3Controls.ini 与 RE3Controls.log。
卸载：删除该 DLL（及 ini）。

本版新增
--------
- 左右手视角随时可切（Camera/ShoulderSwapAlways=1，不瞄准也能切；刀仍在 LB）。默认人物在屏幕左侧（克里斯在左、谢娃在右；Camera/ShoulderAuto、
  ShoulderLeftKinds）。瞄准时按 RB 仍可手动切换。
- 普通枪械变焦：瞄准时 F 放大、C 缩小（Aim/ZoomKeys、ZoomFovStep、
  ZoomMaxStep）。狙击镜保留自身变焦。
- 狙击开镜可走动（ScopeWalk=1），且不再被 mod 干扰镜内瞄准。
- 快速挥刀时可用鼠标/右摇杆转向。

首次启动提示
------------
re5dx9.exe 外有 Enigma Protector，启动后数秒内校验自身镜像，mod 会等待
（HookDelayMs=3000）再挂钩子。若弹出 "Program integrity check failed" 并退出，
重新启动一次或在 [Advanced] 里调大 HookDelayMs。

许可
----
RE3Controls：MIT（c) bananzaza 及贡献者；MinHook：BSD 2 条款（c) TsudaKageyu。
非官方构建，再分发请保留两份许可文件。